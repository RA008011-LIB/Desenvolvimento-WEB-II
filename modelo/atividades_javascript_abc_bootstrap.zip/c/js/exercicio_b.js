const frm = document.querySelector("form")
const resp = document.querySelector("h3")

frm.addEventListener("submit", (e)=>{
    e.preventDefault()

    const chinchilas = Number(frm.inChinchilas.value)
    const anos = Number(frm.inAnos.value)

    let resposta = ""

    for (let i = 1; i <= anos; i++) {
        const total = chinchilas * 3 ** (i - 1)
        resposta = resposta + `${i}º Ano: ${total} Chinchilas\n`
    }

    resp.innerText = resposta
})
