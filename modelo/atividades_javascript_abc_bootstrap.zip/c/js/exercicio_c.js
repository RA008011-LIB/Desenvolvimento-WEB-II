const frm = document.querySelector("form")
const resp = document.querySelector("h3")

frm.addEventListener("submit", (e)=>{
    e.preventDefault()

    const numero = Number(frm.inNumero.value)

    let divisores = ""
    let soma = 0

    for (let i = 1; i < numero; i++) {
        if (numero % i == 0) {
            divisores = divisores + i + ", "
            soma = soma + i
        }
    }

    if (soma == numero) {
        resp.innerText = `Divisores do ${numero}: ${divisores}(Soma: ${soma})\n${numero} é um Número Perfeito`
    } else {
        resp.innerText = `Divisores do ${numero}: ${divisores}(Soma: ${soma})\n${numero} não é um Número Perfeito`
    }
})
